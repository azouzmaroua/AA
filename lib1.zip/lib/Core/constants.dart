import 'package:flutter/material.dart';

// const kMainColor = Color.fromARGB(255, 155, 155, 155);
// const colorV = Color.fromARGB(241, 227, 226, 226);
// const colorIcon = Color.fromARGB(240, 72, 72, 72);

const kLogo = 'assets/images/logo.png';
const kName = 'name';
const kAddress = 'address';

const kEmail = 'email';

const kPhoneNumber = 'phone number';
