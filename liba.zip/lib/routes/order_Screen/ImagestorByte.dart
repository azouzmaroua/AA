import 'dart:typed_data';

late Uint8List theimageThatComesfromThePrinter ;
