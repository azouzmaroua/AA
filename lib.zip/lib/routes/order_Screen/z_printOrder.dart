import 'dart:ffi';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:esc_pos_bluetooth/esc_pos_bluetooth.dart';
import 'package:esc_pos_utils/esc_pos_utils.dart';

import 'package:flutter/scheduler.dart';

class PrintOrder extends StatefulWidget {
  PrintOrder({Key? key}) : super(key: key);

  @override
  State<PrintOrder> createState() => _PrintOrderState();
}

class _PrintOrderState extends State<PrintOrder> {
  PrinterBluetoothManager _PrinteMange = PrinterBluetoothManager();

  List<PrinterBluetooth> _deviesBlutoth = [];
  @override
  void initState() {
    // TODO: implement initState
    intPrintert();
    super.initState();
  }

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("imprimer la facture"),
        centerTitle: true,
        backgroundColor: Colors.white,
      ),
      body: _deviesBlutoth.isEmpty
          ? Center(child: Text("pas de machines détecté"))
          : ListView.builder(
              itemCount: _deviesBlutoth.length,
              itemBuilder: (context, index) {
                return ListTile(
                  leading: Icon(Icons.print),
                  title: Text(_deviesBlutoth[index].address.toString()),
                  subtitle: Text(_deviesBlutoth[index].name.toString()),
                  onTap: () {},
                );
              }),
    );
  }

//
  void intPrintert() {
    _PrinteMange.startScan(Duration(seconds: 3));
    _PrinteMange.scanResults.listen((event) {
      if (mounted) return;
      setState(() => _deviesBlutoth = event);
    });
  }

  //
  Future<void> sartPrint(PrinterBluetooth printer) async {
    _PrinteMange.selectPrinter(printer);
    //final result = await _PrinteMange.printTicket(testTicket);
  }

  //

  //Future<Ticket> testTicket() {
  //  final Ticket ticket = Ticket(PaperSize.mm80);
  // ticket.text();
  // ticket.cut();
  ////  return ticket;
  // }

  //

}
