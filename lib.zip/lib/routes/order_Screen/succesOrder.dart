import 'package:flutter/material.dart';
import 'package:my_parfum/data/addOrders.dart';
import 'package:my_parfum/routes/order_Screen/newOrderScreen.dart';
import 'package:my_parfum/routes/order_Screen/screenChosingProduct.dart';
import 'package:my_parfum/soundUi.dart';
import 'package:my_parfum/theme.dart';
import 'package:my_parfum/widgets/custom/CustomButton.dart';
import 'package:my_parfum/widgets/custom/customText.dart';

class SuccesOrder extends StatefulWidget {
  SuccesOrder({Key? key}) : super(key: key);

  @override
  State<SuccesOrder> createState() => _SuccesOrderState();
}

class _SuccesOrderState extends State<SuccesOrder> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            //print ticket
            //#####################################################################

            Container(
              padding: EdgeInsets.all(10),
              child: Column(
                children: [
                  CustomText(
                    text: '----------------------------------------',
                    TextSize: 21,
                    TextColor: Colors.black,
                    TextWeight: FontWeight.bold,
                  ),
                  //
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      CustomText(
                        text: 'N°$numberOrder',
                        TextSize: 18,
                        TextColor: colorGray,
                        TextWeight: FontWeight.w500,
                      ),
                      CustomText(
                        text: dataEntreOrder.toString().substring(0, 19),
                        TextSize: 16,
                        TextColor: Colors.black,
                        TextWeight: FontWeight.w700,
                      ),
                    ],
                  ),
                  //

                  //
                  SizedBox(
                    height: 70 * double.parse("${listOrder.length}"),
                    child: ListView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemCount: listOrder.length,
                        itemBuilder: (context, index) {
                          return Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  CustomText(
                                    text: listOrder[index]["nameProduct"],
                                    TextSize: 21,
                                    TextColor: Colors.black,
                                    TextWeight: FontWeight.w500,
                                  ),
                                  CustomText(
                                    text: listOrder[index]["type_Prodct"],
                                    TextSize: 15,
                                    TextColor: Colors.black,
                                    TextWeight: FontWeight.w200,
                                  ),
                                ],
                              ),
                              CustomText(
                                text: listOrder[index]["type_Prodct"] ==
                                        "Parfum"
                                    ? listOrder[index]["count_ml"].toString() +
                                        " ml"
                                    : listOrder[index]["count_peieces"]
                                            .toString() +
                                        " peieces".toString(),
                                TextSize: 19,
                                TextColor: Colors.black,
                                TextWeight: FontWeight.w600,
                              ),
                              CustomText(
                                text: listOrder[index]["price"].toString() +
                                    " DA",
                                TextSize: 19,
                                TextColor: Colors.black,
                                TextWeight: FontWeight.w600,
                              ),
                            ],
                          );
                        }),
                  ),
                  //
                  Text('----------------------------------------',
                      style: TextStyle(
                        fontSize: 21,
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                      )),
                  //

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      CustomText(
                        text: 'Total',
                        TextSize: 18,
                        TextColor: colorGray,
                        TextWeight: FontWeight.w500,
                      ),
                      CustomText(
                        text: '$totalPrice DA',
                        TextSize: 18,
                        TextColor: Colors.black,
                        TextWeight: FontWeight.bold,
                      ),
                    ],
                  ),
                  //

                  CustomText(
                    text: '----------------------------------------',
                    TextSize: 21,
                    TextColor: Colors.black,
                    TextWeight: FontWeight.bold,
                  ),
                ],
              ),
            ),

            //#####################################################################
            Icon(
              Icons.check_circle_outline,
              size: 100,
              color: greenColor,
            ),
            CustomText(
              text: 'Command N$numberOrder a été',
              TextSize: 21,
              TextColor: greenColor,
              TextWeight: FontWeight.bold,
            ),
            CustomText(
              text: 'Enregistrer avec succés',
              TextSize: 21,
              TextColor: greenColor,
              TextWeight: FontWeight.bold,
            ),
            Container(
              width: 700,
              height: 50,
              margin: EdgeInsets.all(20),
              child: CustomGeneralButton(
                color: blueColor,
                text: "imprimer l'étiquette",
                onTap: () {},
              ),
            ),
            //button green
            Container(
              width: 700,
              height: 50,
              margin: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
              child: CustomGeneralButton(
                color: greenColor,
                text: 'confirmer',
                onTap: () {
                  tapButton1();
                  listOrder.clear();
                  indexPageView = 2;
                  Navigator.of(context).pushReplacementNamed('home Screen');
                },
              ),
            ),
          ]),
    );
  }
}
