import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter/material.dart';
import 'package:my_parfum/functions/getTime.dart';
import 'package:my_parfum/routes/statistiques_screens/widget_dropDown_time.dart';
import 'package:my_parfum/routes/statistiques_screens/widget_scrol_monthes_button.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:intl/intl.dart';

class stret_static extends StatefulWidget {
  const stret_static({Key? key}) : super(key: key);
  _stret_staticState createState() => _stret_staticState();
}

class _stret_staticState extends State<stret_static> {
  late List<ChartSampleData> _chartData;
  late TooltipBehavior _tooltipBehavior;
  @override
  void initState() {
    _chartData = getChartData(); //hna l problem klifach njib liste
    _tooltipBehavior = TooltipBehavior(enable: true);
    getTimeToDay();
    super.initState();
  }

  bool ladingStatistiquesScreen = false;

  //get Time To Day

  String dataEntree = "2022-11-15";
  String dataEntreeMonth = "11";
  String dataEntreeYear = "2022";

  Future getTimeToDay() async {
    print("2================================");

// 1 first / get time
    var dataEntreeGet = await getTime();
    dataEntree = '$dataEntreeGet';
    dataEntree = dataEntree.substring(0, 10);
    dataEntreeMonth = dataEntree.substring(5, 7);
    dataEntreeYear = dataEntree.substring(0, 4);
    setState(() {
      dropdownValueMonth = listMonth[int.parse(dataEntreeMonth) - 1];
      activeButtonMonth = int.parse(dataEntreeMonth) - 1;
      //
      dropdownValueYear = dataEntreeYear;
    });

    getData();
  }

  //2 second get
  List listVentes = [];

  getData() async {
    var refranceOrder = await FirebaseFirestore.instance.collection("Orders");

    await refranceOrder
        .where("IdTimeEnter",
            isLessThanOrEqualTo: '$dataEntreeYear-$dataEntreeMonth-31')
        .where("IdTimeEnter",
            isGreaterThanOrEqualTo: '$dataEntreeYear-$dataEntreeMonth-01')
        .get()
        .then((value) {
      value.docs.forEach((element) {
        print("22================================");
        print(element.data());

        // x = x.addAll({"idTime": "${element.id}"});
        // x = x.addAll({"idTime": "${element.id}"});

        setState(() {
          listVentes.add(element.data());
        });
      });
      //قلب ليست
      setState(() {
        List x = listVentes.reversed.toList();
        ;
        listVentes.clear();
        listVentes = x;

        ////ladingVentesScreen

        ladingStatistiquesScreen = true;
      });
    });
    print("3================================");
    print("$listVentes");
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      body: SfCartesianChart(
        legend: Legend(isVisible: true),
        tooltipBehavior: _tooltipBehavior,
        title: ChartTitle(text: 'Statistiques'),
        series: <ChartSeries<ChartSampleData, DateTime>>[
          ColumnSeries<ChartSampleData, DateTime>(
            dataSource: _chartData,
            name: 'Profits',
            color: Color(0xff5cf17c),
            xValueMapper: (ChartSampleData data, _) => data.x,
            yValueMapper: (ChartSampleData data, _) => data.revenue,
            dataLabelSettings: DataLabelSettings(isVisible: true),
            borderRadius: BorderRadius.all(Radius.circular(9)),
            spacing: 2,
          ),
          ColumnSeries<ChartSampleData, DateTime>(
              spacing: 2,
              dataSource: _chartData,
              name: 'Revenue',
              color: Color(0xff87b8f3),
              xValueMapper: (ChartSampleData data, _) => data.x,
              yValueMapper: (ChartSampleData data, _) => data.profit,
              dataLabelSettings: DataLabelSettings(isVisible: true),
              borderRadius: BorderRadius.all(Radius.circular(9))),
        ],
        primaryXAxis: DateTimeAxis(
            edgeLabelPlacement: EdgeLabelPlacement.shift,
            dateFormat: DateFormat.MMM(),
            intervalType: DateTimeIntervalType.months,
            majorGridLines: MajorGridLines(width: 0)),
        primaryYAxis: NumericAxis(labelFormat: '{value} DA'),
      ),
    ));
  }

  List<ChartSampleData> getChartData() {
    List<ChartSampleData> l = [];
    int i = 0;
    listVentes.forEach((element) {
      if (i < 10) {
        ChartSampleData a = ChartSampleData(
            element[" IdTimeEnter"],
            element["total-reveresnse-ordres-payes"],
            element["total-profti-ordres-payes"]);
        l.add(a);
      }
      i++;
    });
    return l;
    // list hadi farga ?????
    // hna kon nhot l code ta3 for each mana9derch n3gb lie st
    //
  }
}

class ChartSampleData {
  ChartSampleData(this.x, this.revenue, this.profit);
  final DateTime x;
  final int revenue;
  final int profit;
}
